EoS table RG(SLY4) for cold neutron star matter in beta-equilibrium downloaded from https://compose.obspm.fr

References to the original work:

1. F. Gulminelli and Ad. R. Raduta, Phys. Rev. C 92, 055803 (2015)
2. E. Chabanat, Ph.D. thesis, University Claude Bernard Lyon-1, Lyon, France, 1995.
3. P. Danielewicz et J. Lee, Nucl. Phys. A818, 36 (2009).


