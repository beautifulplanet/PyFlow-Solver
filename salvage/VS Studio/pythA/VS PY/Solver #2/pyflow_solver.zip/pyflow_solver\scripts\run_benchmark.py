import sys
import os
import matplotlib.pyplot as plt

# This is the crucial part that fixes the ModuleNotFoundError
# It adds the parent directory ('pyflow_project') to the Python path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from pyflow.grid import Grid
from pyflow.solver import solve_lid_driven_cavity

if __name__ == '__main__':
    print("Setting up simulation...")
    # Simulation Parameters
    NPOINTS = 64
    L = 1.0
    Re = 100.0
    dt = 0.001
    T = 5.0

    # Create the grid and run the solver
    grid = Grid(NPOINTS, L)
    print("Running solver...")
    u, v, p = solve_lid_driven_cavity(grid, Re, dt, T)
    print("Solver finished. Visualizing results...")

    # Visualization
    plt.figure(figsize=(8, 8))
    plt.contourf(grid.X, grid.Y, p, alpha=0.5, cmap='viridis')
    plt.colorbar(label='Pressure')
    plt.quiver(grid.X, grid.Y, u, v, color='black')
    plt.title(f'Lid-Driven Cavity Flow at Re={Re}')
    plt.xlabel('X')
    plt.ylabel('Y')
    plt.show()
