import numpy as np

class Grid:
    """
    Manages the creation and properties of a 2D computational grid.
    This class creates a uniform, staggered grid.
    """
    def __init__(self, NPOINTS: int, L: float):
        self.NPOINTS = NPOINTS
        self.L = L
        self.dx = L / (NPOINTS - 1)
        self.dy = L / (NPOINTS - 1)
        self.X, self.Y = np.meshgrid(np.linspace(0, L, NPOINTS), np.linspace(0, L, NPOINTS))
