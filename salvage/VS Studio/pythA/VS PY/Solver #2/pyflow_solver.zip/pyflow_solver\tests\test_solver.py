
import sys
import os
import numpy as np
# Add project root to sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from pyflow.grid import Grid
from pyflow.solver import solve_lid_driven_cavity

import matplotlib.pyplot as plt
def test_lid_driven_cavity_center_velocity():
    """
    Test the centerline velocity for a classic lid-driven cavity at Re=100.
    Reference: Ghia et al. (1982) benchmark data.
    """
    # Try different grid sizes and simulation times
    for NPOINTS, T in [(32, 10.0), (64, 10.0), (64, 20.0)]:
        L = 1.0
        Re = 100.0
        dt = 0.001
        print(f"\nRunning with NPOINTS={NPOINTS}, T={T}")
        grid = Grid(NPOINTS, L)
        u, v, p = solve_lid_driven_cavity(grid, Re, dt, T)
        center_idx = NPOINTS // 2
        u_centerline = u[:, center_idx]
        print(f"Centerline u-velocity at y=0.5: {u_centerline[center_idx]}")
        # Plot the centerline velocity profile
        y = grid.Y[:, center_idx]
        plt.figure()
        plt.plot(u_centerline, y, marker='o')
        plt.title(f'Vertical Centerline u-velocity (N={NPOINTS}, T={T})')
        plt.xlabel('u')
        plt.ylabel('y')
        plt.grid()
        plt.show()
        # Ghia et al. (1982) value for u at (x=0.5, y=0.5) for Re=100 is about 0.062
        if np.isclose(u_centerline[center_idx], 0.062, atol=0.02):
            print("Test passed: Centerline velocity matches benchmark within tolerance.")
        else:
            print(f"Test failed: Centerline u-velocity {u_centerline[center_idx]} deviates from benchmark.")

if __name__ == "__main__":
    test_lid_driven_cavity_center_velocity()
    print("Test passed: Centerline velocity matches benchmark within tolerance.")